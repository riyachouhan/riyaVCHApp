package com.vch.activities;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import com.google.android.material.navigation.NavigationView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.vch.R;
import com.vch.fragmets.AboutUsFragment;
import com.vch.fragmets.ContactsUsFragment;
import com.vch.fragmets.FragmentTermsConditions;
import com.vch.fragmets.HomeFragment;
import com.vch.fragmets.LoyaltyProgramFragment;
import com.vch.fragmets.MyAddressFragment;
import com.vch.fragmets.OrderHistoryFragment;
import com.vch.fragmets.PartyOrderFragment;
import com.vch.fragmets.PrivacyPolicyFragment;
import com.vch.fragmets.ProfileFragment;
import com.vch.fragmets.ReferNEarnFragment;
import com.vch.fragmets.SearchFragment;
import com.vch.fragmets.ShippingPolicyFragment;
import com.vch.fragmets.TiffinBoxFragment;
import com.vch.response.UserDetail;
import com.vch.utiles.App;
import com.vch.utiles.AppConfig;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static ActionBarDrawerToggle mDrawerToggle;
    private static TextView name;
    private static CircleImageView imageView;
    private static boolean mToolBarNavigationListenerIsRegistered = false;
    private static FragmentManager fm;
    private static ActionBar actionBar;
    boolean doubleBackToExitPressedOnce = false;
    private static AppCompatActivity activity;
    public static UserDetail detail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        if (getIntent().getExtras() != null) {
            detail = getIntent().getExtras().getParcelable("userData");
            fm = getSupportFragmentManager();
            activity = this;
            Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            actionBar = getSupportActionBar();

            final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

            mDrawerToggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(mDrawerToggle);
            mDrawerToggle.syncState();

            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);

            View view = navigationView.getHeaderView(0);
            name = view.findViewById(R.id.name_TV);
            imageView = view.findViewById(R.id.profile_CIV);
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (drawer.isDrawerOpen(GravityCompat.START)) {
                        drawer.closeDrawer(GravityCompat.START);
                    }
                    addFragment(new ProfileFragment(), true);
                }
            });

            setname(this);

            addFragment(new HomeFragment(), false);

        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {

            if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                getSupportFragmentManager().popBackStack();
            } else if (!doubleBackToExitPressedOnce) {
                this.doubleBackToExitPressedOnce = true;

                AppConfig.showToast("Please click BACK again to exit.");

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            } else {
                super.onBackPressed();
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        MenuItem search = menu.findItem(R.id.menu_search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(search);
        search(searchView);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        return super.onOptionsItemSelected(item);
    }


    private void search(SearchView searchView) {

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.equals(""))
                    addFragment(new HomeFragment(), false);
                else
                    addFragment(SearchFragment.newInstance(newText), false);
                return true;
            }
        });
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        Fragment fragment;
        switch (id) {
            case R.id.nav_home:

                clearFragmentStack();
                fragment = new HomeFragment();
                break;

            case R.id.nav_aboutus:

                clearFragmentStack();
                fragment = new AboutUsFragment();
                break;


            case R.id.nav_order_history:

                fragment = new OrderHistoryFragment();
                break;
            case R.id.nav_tiffin_box:

                fragment = new TiffinBoxFragment();
                break;
            case R.id.nav_refer_n_earn:

                fragment = new ReferNEarnFragment();
                break;
            case R.id.nav_loyalty_program:

                fragment = new LoyaltyProgramFragment();
                break;
            case R.id.nav_party_order:

                fragment = new PartyOrderFragment();
                break;
            case R.id.nav_my_address:

                fragment = new MyAddressFragment();
                break;
            case R.id.nav_contact_us:

                fragment = new ContactsUsFragment();
                break;

            case R.id.nav_privacy_policy:

                fragment = new PrivacyPolicyFragment();
                break;

            case R.id.nav_terms_conditions:

                fragment = new FragmentTermsConditions();
                break;

            case R.id.nav_shipping_policy:

                fragment = new ShippingPolicyFragment();
                break;

            case R.id.nav_sign_out:

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HomeActivity.this);
                alertDialogBuilder.setTitle("Do you want to Sign Out ?").setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        App.editor.clear();
                        startActivity(new Intent(HomeActivity.this,BaseActivity.class));
                        finish();

                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
                return true;
            default:
                clearFragmentStack();
                fragment = new HomeFragment();
                break;
        }
        addFragment(fragment, true);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public static void addFragment(Fragment fragment, boolean addToBackStack) {

        FragmentTransaction transaction = fm.beginTransaction();
        transaction.replace(R.id.container, fragment, "");
        //if (!tag.equals("Home"))
        if (addToBackStack) {
            transaction.addToBackStack(null);
        }
        transaction.commit();
    }

    public static void clearFragmentStack() {
        fm.popBackStackImmediate(0, FragmentManager.POP_BACK_STACK_INCLUSIVE);
    }

    public static void enableViews(boolean enable) {

        if (enable) {
            actionBar.setHomeAsUpIndicator(R.drawable.ic_arrow_left_white);
            actionBar.setDisplayHomeAsUpEnabled(false);
            // Remove hamburger
            mDrawerToggle.setDrawerIndicatorEnabled(false);
            // Show back button
            actionBar.setDisplayHomeAsUpEnabled(true);

            if (!mToolBarNavigationListenerIsRegistered) {
                mDrawerToggle.setToolbarNavigationClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Doesn't have to be onBackPressed
                        activity.onBackPressed();
                    }
                });

                mToolBarNavigationListenerIsRegistered = true;
            }

        } else {

            // Remove back button

            // Show hamburger
            mDrawerToggle.setDrawerIndicatorEnabled(true);
            //mDrawerToggle.setDrawerArrowDrawable();
            // Remove the/any drawer toggle listener
            mDrawerToggle.setToolbarNavigationClickListener(null);
            mToolBarNavigationListenerIsRegistered = false;
        }
    }
    public static void setname(Activity activity){
        name.setText(detail.getUserName());

        Glide.with(activity).asBitmap().load(detail.getUserProfileImage()).into(new SimpleTarget<Bitmap>() {
            @Override
            public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                imageView.setImageBitmap(resource);
            }

            @Override
            public void onLoadFailed(@Nullable Drawable errorDrawable) {
                super.onLoadFailed(errorDrawable);
                imageView.setImageResource(R.drawable.default_user);
            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }
}
